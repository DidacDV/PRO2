#include "BinTreeIOEst.hh"

void read_bintree_est(BinTree<Estudiant>& a) {
        BinTree<Estudiant> r;
        BinTree<Estudiant> l;
        Estudiant e;
        e.llegir();

    if (e.consultar_DNI() != 0 or e.consultar_nota() != 0) {
        read_bintree_est(l);
        read_bintree_est(r);
        a = BinTree<Estudiant>(e,l,r);
    }
    else a = BinTree<Estudiant>();
}

