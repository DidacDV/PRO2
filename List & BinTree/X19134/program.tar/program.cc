#include <iostream>
#include "LlistaIOParInt.hh"
using namespace std;


int main () {
    list<ParInt> l;
    list<ParInt>::iterator it;
    LlegirLlistaParInt(l);
    int x;
    int contador = 0;
    int suma = 0;
    cin >> x;
    for (it = l.begin(); it != l.end(); ++it) {
        ParInt p = *it;
        if (p.primer() == x) {
            ++contador;
            suma += p.segon();
        }
    }
    cout << x << " " << contador << " " << suma << endl;


}