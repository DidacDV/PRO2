#include <iostream>
#include "BinTree.hh"
#include "ParInt.hh"
#include "BinTreeIOParInt.hh"

using namespace std;

void busqueda(BinTree<ParInt> arbre, int x, int contador, bool& trobat) {
    
    if (arbre.empty()) trobat = false;
    else if (arbre.value().primer() == x) {
        trobat = true;
        cout << x << " " << arbre.value().segon() << " " << contador << endl;
    }
    else {
        busqueda(arbre.left(), x, contador+1, trobat);

        if (not trobat) busqueda(arbre.right(), x, contador+1, trobat);
    }
    

    
}





int main() {
    BinTree<ParInt> arbre;
    read_bintree_parint(arbre);
    int x;
    int contador = 0;
    while (cin >> x)
    {
        bool trobat = false;
        busqueda(arbre, x, contador, trobat);
        if (not trobat) cout << -1 << endl;
    }
    
}
