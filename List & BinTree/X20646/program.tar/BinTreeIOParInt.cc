#include <iostream>
#include "ParInt.hh"
#include "BinTree.hh"
#include "BinTreeIOParInt.hh"

using namespace std;

void read_bintree_parint(BinTree<ParInt>& a) {

    ParInt par;
    BinTree<ParInt> bl, br;

    if (par.llegir()) {
        read_bintree_parint(bl);
        read_bintree_parint(br);
        a = BinTree<ParInt>(par, bl, br);
    }
    else a = BinTree<ParInt>();
}
