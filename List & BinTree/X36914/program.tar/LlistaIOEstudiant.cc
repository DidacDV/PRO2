#include "LlistaIOEstudiant.hh"
#include "Estudiant.hh"
void LlegirLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::iterator it = l.end();
    Estudiant e;
    e.llegir();
    while (e.consultar_DNI() and e.consultar_nota() != 0) {
        l.insert(it,e);
        --it;
        e.llegir();
    }
}



