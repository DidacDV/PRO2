#include <iostream>
#include <list>
#include "LlistaIOEstudiant.hh"
using namespace std;



int main () {
    list <Estudiant> l;
    LlegirLlistaEstudiant(l);
    int dni1;
    cin >> dni1;
    int cont = 0;
    list <Estudiant>::iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        Estudiant est = *it;
        if (est.consultar_DNI() == dni1) ++cont;
    }
    cout << dni1 << " " << cont << endl;
}