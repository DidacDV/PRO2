#include "CuaIOParInt.hh"
using namespace std;


void llegirCuaParInt(queue<ParInt>& c) {
ParInt n;
while (n.llegir()) {
    c.push(n);
}
}
void escriureCuaParInt(queue<ParInt> c) {
// Pre: cert
// Post: s’han escrit al canal estandar de sortida els elements de c
    while (not c.empty()) {
        ParInt n = c.front();
        n.escriure();
        c.pop();
    }

}