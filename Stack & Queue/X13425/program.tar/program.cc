#include <queue>
#include "CuaIOParInt.hh"
#include <iostream>
using namespace std;

void organitza(queue<ParInt> &c, queue<ParInt> &c1, queue<ParInt> &c2) {
    int suma1 = 0;
    int suma2 = 0;
    ParInt n;
    n = c.front();
    suma1 += n.segon();
    c1.push(n);
    c.pop();

    n = c.front();
    c.pop();
    suma2 += n.segon();
    c2.push(n);
    while (not c.empty()) {
        n = c.front();
        if (suma1 <= suma2) {
            c1.push(n);
            suma1 += n.segon();
        }
        else {
            c2.push(n);
            suma2 += n.segon();
        }
        c.pop();
    }
}

int main () {
    queue<ParInt> c;
    llegirCuaParInt(c);
    if (not c.empty()) {
        queue<ParInt> c1;
        queue<ParInt> c2;
        organitza(c,c1,c2);
        escriureCuaParInt(c1);
        cout << endl;
        escriureCuaParInt(c2);
    }
    else cout << endl;
}